<?php
header("Location: login.php"); //hyperdeveloper
exit;