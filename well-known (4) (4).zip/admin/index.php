<?php
header("Location: /admin/login.php"); //hyperdeveloper
exit;